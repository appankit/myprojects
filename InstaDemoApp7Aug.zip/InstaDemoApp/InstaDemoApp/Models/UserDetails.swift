

import Foundation
import SwiftyJSON

public final class UserDetails: NSObject, NSCoding,JSONable {

  // MARK: Declaration for string constants to be used to decode and also serialize.
  private struct SerializationKeys {
    static let age = "age"
    static let note = "note"
    static let profileImages = "profile_images"
    static let id = "id"
    static let name = "name"
    static let profileImage = "profile_image"
  }

  // MARK: Properties
  public var age: String?
  public var note: String?
  public var profileImages: [ProfileImages]?
  public var id: String?
  public var name: String?
  public var profileImage: [ProfileImage]?

  // MARK: SwiftyJSON Initializers
  /// Initiates the instance based on the object.
  ///
  /// - parameter object: The object of either Dictionary or Array kind that was passed.
  /// - returns: An initialized instance of the class.
  public convenience init(object: Any) {
    self.init(parameter: JSON(object))
  }

  /// Initiates the instance based on the JSON that was passed.
  ///
  /// - parameter json: JSON object from SwiftyJSON.
    public required init(parameter json: JSON) {
    age = json[SerializationKeys.age].string
    note = json[SerializationKeys.note].string
    if let items = json[SerializationKeys.profileImages].array { profileImages = items.map { ProfileImages(parameter: $0) } }
    id = json[SerializationKeys.id].string
    name = json[SerializationKeys.name].string
    if let items = json[SerializationKeys.profileImage].array { profileImage = items.map { ProfileImage(parameter: $0) } }
  }

  /// Generates description of the object in the form of a NSDictionary.
  ///
  /// - returns: A Key value pair containing all valid values in the object.
  public func dictionaryRepresentation() -> [String: Any] {
    var dictionary: [String: Any] = [:]
    if let value = age { dictionary[SerializationKeys.age] = value }
    if let value = note { dictionary[SerializationKeys.note] = value }
    if let value = profileImages { dictionary[SerializationKeys.profileImages] = value.map { $0.dictionaryRepresentation() } }
    if let value = id { dictionary[SerializationKeys.id] = value }
    if let value = name { dictionary[SerializationKeys.name] = value }
    if let value = profileImage { dictionary[SerializationKeys.profileImage] = value.map { $0.dictionaryRepresentation() } }
    return dictionary
  }

  // MARK: NSCoding Protocol
  required public init(coder aDecoder: NSCoder) {
    self.age = aDecoder.decodeObject(forKey: SerializationKeys.age) as? String
    self.note = aDecoder.decodeObject(forKey: SerializationKeys.note) as? String
    self.profileImages = aDecoder.decodeObject(forKey: SerializationKeys.profileImages) as? [ProfileImages]
    self.id = aDecoder.decodeObject(forKey: SerializationKeys.id) as? String
    self.name = aDecoder.decodeObject(forKey: SerializationKeys.name) as? String
    self.profileImage = aDecoder.decodeObject(forKey: SerializationKeys.profileImage) as? [ProfileImage]
  }

  public func encode(with aCoder: NSCoder) {
    aCoder.encode(age, forKey: SerializationKeys.age)
    aCoder.encode(note, forKey: SerializationKeys.note)
    aCoder.encode(profileImages, forKey: SerializationKeys.profileImages)
    aCoder.encode(id, forKey: SerializationKeys.id)
    aCoder.encode(name, forKey: SerializationKeys.name)
    aCoder.encode(profileImage, forKey: SerializationKeys.profileImage)
  }

}
