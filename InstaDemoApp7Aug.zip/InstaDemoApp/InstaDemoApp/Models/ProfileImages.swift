

import Foundation
import SwiftyJSON

public final class ProfileImages: NSObject, NSCoding,JSONable {

  // MARK: Declaration for string constants to be used to decode and also serialize.
  private struct SerializationKeys {
    static let mediaUrl = "media_url"
    static let mediaType = "media_type"
  }

  // MARK: Properties
  public var mediaUrl: String?
  public var mediaType: Int?

  // MARK: SwiftyJSON Initializers
  /// Initiates the instance based on the object.
  ///
  /// - parameter object: The object of either Dictionary or Array kind that was passed.
  /// - returns: An initialized instance of the class.
  public convenience init(object: Any) {
    self.init(parameter: JSON(object))
  }

  /// Initiates the instance based on the JSON that was passed.
  ///
  /// - parameter json: JSON object from SwiftyJSON.
    public required init(parameter json: JSON) {
    mediaUrl = json[SerializationKeys.mediaUrl].string
    mediaType = json[SerializationKeys.mediaType].int
  }

  /// Generates description of the object in the form of a NSDictionary.
  ///
  /// - returns: A Key value pair containing all valid values in the object.
  public func dictionaryRepresentation() -> [String: Any] {
    var dictionary: [String: Any] = [:]
    if let value = mediaUrl { dictionary[SerializationKeys.mediaUrl] = value }
    if let value = mediaType { dictionary[SerializationKeys.mediaType] = value }
    return dictionary
  }

  // MARK: NSCoding Protocol
  required public init(coder aDecoder: NSCoder) {
    self.mediaUrl = aDecoder.decodeObject(forKey: SerializationKeys.mediaUrl) as? String
    self.mediaType = aDecoder.decodeObject(forKey: SerializationKeys.mediaType) as? Int
  }

  public func encode(with aCoder: NSCoder) {
    aCoder.encode(mediaUrl, forKey: SerializationKeys.mediaUrl)
    aCoder.encode(mediaType, forKey: SerializationKeys.mediaType)
  }

}
