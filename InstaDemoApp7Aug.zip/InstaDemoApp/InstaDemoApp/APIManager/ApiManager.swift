
import UIKit
import Alamofire
import SVProgressHUD

class ApiManager: NSObject {
    static let sharedInstance = ApiManager()
    func requestGETURL(_ strURL: String, success:@escaping (NSArray) -> Void, failure:@escaping (Error) -> Void)
    {
        if(isInternetAvailable() == false)
        {
            let alert = UIAlertController(title: "Alert", message: "Internet Not Available", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            let alertWindow = UIWindow(frame: UIScreen.main.bounds)
            alertWindow.windowLevel = UIWindow.Level.alert
            alertWindow.rootViewController = UIViewController()
            alertWindow.makeKeyAndVisible()
            alertWindow.rootViewController?.dismiss(animated: true, completion: nil)
            alertWindow.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        let mainUrl : String = strURL//"\(self.BaseUrl)\(strURL)"
        Alamofire.request(mainUrl).responseJSON { (responseObject) -> Void in
            if responseObject.result.isSuccess {
                let resJson = responseObject.result.value!
                success(resJson as! NSArray)
            }
            if responseObject.result.isFailure {
                let error : Error = responseObject.result.error!
                failure(error)
            }
        }
    }
    
}
