

import UIKit
import SwiftyJSON
import SDWebImage
class ViewController: UIViewController {

    @IBOutlet weak var tblView: UITableView!
    var userData: [UserDetails]?
    
    let inset: CGFloat = 0
    let minimumLineSpacing: CGFloat = 0
    let minimumInteritemSpacing: CGFloat = 0
    let cellsPerRow = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let nibUserImg = UINib(nibName: "TblCell", bundle: nil)
        tblView.register(nibUserImg, forCellReuseIdentifier: "TblCell")
        tblView.estimatedRowHeight = 400
        tblView.separatorStyle = .none
        tblView.rowHeight = UITableView.automaticDimension
        getUserData()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    func getUserData(){
        ApiManager.sharedInstance.requestGETURL("http://www.mocky.io/v2/5cd2a23731000086283398ad", success: { (response) in
            print(response)
            let json = JSON(response)
            if let resData : [UserDetails] = json.to(type: UserDetails.self) as? [UserDetails] {
                print(resData)
                self.userData = resData
                self.tblView.delegate = self
                self.tblView.dataSource = self
                self.tblView.reloadData()
            }
        }, failure: { (error) in
            print("Error:",error.localizedDescription)
        })
    }
}

extension ViewController: UITableViewDelegate,UITableViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableView.automaticDimension
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  self.userData?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TblCell", for: indexPath) as! TblCell
        var obj = self.userData?[indexPath.row] as!  UserDetails
        cell.lblName.text = obj.name
        cell.lblDescription.text = obj.note
        let nibUserImg = UINib(nibName: "UserProfileImages", bundle: nil)
        cell.collectionView.register(nibUserImg, forCellWithReuseIdentifier: "idUserProfileImages")
        cell.collectionView.delegate = self
        cell.collectionView.dataSource = self
        cell.collectionView.tag = indexPath.row
        return cell
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if self.userData?[collectionView.tag].profileImages == nil{
             return (self.userData?[collectionView.tag].profileImage?.count ?? 0)
        }else{
             return (self.userData?[collectionView.tag].profileImages?.count ?? 0)
        }
       
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       
        var cell = collectionView.dequeueReusableCell(withReuseIdentifier: "idUserProfileImages", for: indexPath) as! UserProfileImages
        if self.userData?[collectionView.tag].profileImages == nil{
            if self.userData?[collectionView.tag].profileImage?.count ?? 0 > 0 && self.userData?[collectionView.tag].profileImage?.count ?? 0 > indexPath.row {
                let obj = self.userData?[collectionView.tag].profileImage?[indexPath.row] as! ProfileImage
                let imgUrl = obj.mediaUrl
                cell.img.sd_setImage(with: URL(string: imgUrl ?? ""), completed: nil)
            }
        }else{
            if self.userData?[collectionView.tag].profileImages?.count ?? 0 > 0{
                let obj = self.userData?[collectionView.tag].profileImages?[indexPath.row] as! ProfileImages
                let imgUrl = obj.mediaUrl
                cell.img.sd_setImage(with: URL(string: imgUrl ?? ""), completed: nil)
            }
        }
            return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: inset, left: inset, bottom: inset, right: inset)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return minimumLineSpacing
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return minimumInteritemSpacing
    }
}
