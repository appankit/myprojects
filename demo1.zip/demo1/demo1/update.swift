//
//  update.swift
//  demo1
//
//  Created by Harry on 6/15/16.
//  Copyright © 2016 Harry. All rights reserved.
//

import UIKit

class update: UIViewController {
 var uD = NSUserDefaults.standardUserDefaults()
    var arrName = NSMutableArray()
    var dat = NSMutableArray()
    @IBOutlet weak var txtTask: UITextField!
    @IBOutlet weak var dt: UIDatePicker!
    
    
    @IBAction func click(sender: AnyObject) {
      
        var date1 = dt.date
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let date2 = dateFormatter.stringFromDate(date1)
     
        arrName.replaceObjectAtIndex(index, withObject: txtTask.text!)
        dat.replaceObjectAtIndex(index, withObject: date2)
        uD.setValue(arrName, forKey: "name")
        uD.setValue(dat, forKey: "dt")
        var sec:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        var sec2 = sec.instantiateViewControllerWithIdentifier("display")
        self.presentViewController(sec2, animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        if (uD.valueForKey("name") != nil)
        {
          var arrName12 = uD.valueForKey("name") as! NSMutableArray
            var j = 0
        for var i in arrName12
        {
         
            
            arrName.addObject(i)
           
        }
            print(arrName)
        }
        
        if (uD.valueForKey("dt") != nil)
        {
            var arrName123 = uD.valueForKey("dt") as! NSMutableArray
            var j = 0
            for var i in arrName123
            {
              
                    
                    dat.addObject(i)
              
            }
            print(dat)
        }
        
//        if (uD.valueForKey("Data") != nil)
//        {
//            print(uD.valueForKey("Data")!)
//            arrName = uD.valueForKey("Data") as! NSMutableArray
//            
//           // print(arrName[0][0])
//        }
        
        let strDate = dat[index] as! String
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        dt.date = dateFormatter.dateFromString(strDate)!
        
        txtTask.text = arrName[index] as! String
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
