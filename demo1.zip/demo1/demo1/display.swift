//
//  display.swift
//  demo1
//
//  Created by Harry on 6/14/16.
//  Copyright © 2016 Harry. All rights reserved.
//

import UIKit

class display: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var profile: UIImageView!
    var arr = NSMutableArray()
    var arrName = NSMutableArray()
    var arrtask = NSMutableArray()
    @IBOutlet weak var bDate: UILabel!
    var uD = NSUserDefaults.standardUserDefaults()
    override func viewDidLoad() {
        super.viewDidLoad()
        arr = ["Ankit","Vicky","Chandu"]
        profile.layer.borderWidth = 1
        profile.layer.borderColor = UIColor.blackColor().CGColor
        profile.layer.cornerRadius = profile.frame.height/2
        profile.clipsToBounds = true
        if (uD.valueForKey("Image") != nil)
        {
            profile.image = UIImage(data: uD.valueForKey("Image") as! NSData)
        }
        if (uD.valueForKey("dt") != nil)
        {
          //  bDate.text = String(uD.valueForKey("dt")!)
        }
        
        
        
    
        if (uD.valueForKey("name") != nil)
        {
            print(uD.valueForKey("name")!)
            var arrName1 = uD.valueForKey("name") as! NSMutableArray
            for var i in arrName1
            {
                
                arrName.addObject(i)
            }
         
            
            
        }
        if (uD.valueForKey("dt") != nil)
        {
            print(uD.valueForKey("dt")!)
            var  arrtask1 = uD.valueForKey("dt") as! NSMutableArray
           
            for var i in arrtask1
            {
                
                arrtask.addObject(i)
            }
            // print(arrName[0][0])
            
            
        }
        
        
        // Do any additional setup after loading the view.
    }

    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrName.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cellss = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
       cellss.textLabel?.text = String(arrName[indexPath.row])
        cellss.detailTextLabel?.text = String(arrtask[indexPath.row])
        return cellss
    }
    
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
        let deleteAction = UITableViewRowAction(style: UITableViewRowActionStyle.Normal, title: "Delete" , handler: { (action:UITableViewRowAction!, indexPath:NSIndexPath!) -> Void in
            //I did some work here
           self.arrName.removeObjectAtIndex(indexPath.row)
            self.arrtask.removeObjectAtIndex(indexPath.row)
            self.uD.setValue(self.arrName, forKey: "name")
            self.uD.setValue(self.arrtask, forKey: "dt")
                     tableView.reloadData()
        })
        
        let editAction = UITableViewRowAction(style: UITableViewRowActionStyle.Normal, title: "Edit" , handler: { (action:UITableViewRowAction!, indexPath:NSIndexPath!) -> Void in
            //I did some work here
            index = indexPath.row
         
            var sec:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
            var sec2 = sec.instantiateViewControllerWithIdentifier("update")
            self.presentViewController(sec2, animated: true, completion: nil)

            tableView.reloadData()
        })

        editAction.backgroundColor = UIColor.greenColor()
        
        return [deleteAction,editAction]
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
