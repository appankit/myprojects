//
//  registration.swift
//  demo1
//
//  Created by Harry on 6/14/16.
//  Copyright © 2016 Harry. All rights reserved.
//

import UIKit

class registration: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var txtfname: UITextField!
    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtpwd: UITextField!
    @IBOutlet weak var save: UIButton!
    
    @IBOutlet weak var dp: UIDatePicker!
    var ip = UIImagePickerController()
    var userDef = NSUserDefaults.standardUserDefaults()
    var name = NSMutableArray()
    var email = NSMutableArray()
    var pwd = NSMutableArray()
    var taskDate = NSMutableArray()
    var info = NSMutableArray()
    var temp = NSMutableArray()
     var tempname = NSMutableArray()
     var temptask = NSMutableArray()
    @IBAction func saveClick(sender: AnyObject) {
      
      
       
        var date1 = dp.date
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let date2 = dateFormatter.stringFromDate(date1)
        name.addObject(txtfname.text!)
        taskDate.addObject(date2)
        userDef.setValue(name, forKey:"name")
        userDef.setValue(taskDate, forKey:"dt")
    

                                                                                            //temp.addObject([txtfname.text!,date2])
                                                                                            //userDef.setValue(temp, forKey: "Data")
        
        var sec:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
    
        var sec2 = sec.instantiateViewControllerWithIdentifier("display")
        presentViewController(sec2, animated: true, completion: nil)
        
        
    //    userDef.setValue(taskDate, forKey: "dt")
        
        
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        if (userDef.valueForKey("name") != nil)
        {
            var ar = userDef.valueForKey("name") as! NSMutableArray
            for var i in ar
            {
                
                name.addObject(i)
            }
        
        }
        
        if (userDef.valueForKey("dt") != nil)
        {
            var ar = userDef.valueForKey("dt") as! NSMutableArray
            for var i in ar
            {
                
                taskDate.addObject(i)
            }
            
        }
       // print(name)
//        if (userDef.valueForKey("Data") != nil)
//        {
//          //  print(userDef.valueForKey("Data")!)
//            var arrName = userDef.valueForKey("Data") as! NSMutableArray
//          
//            for var i in arrName
//            {
//                
//                temp.addObject(i)
//            }
//            print(temp)
//            
//        }
//        
        
        img.layer.borderColor = UIColor.blackColor().CGColor
        img.layer.borderWidth = 1
        img.layer.cornerRadius = img.frame.height/2
        img.clipsToBounds = true
        
        txtfname.delegate = self
        txtpwd.delegate = self
        txtemail.delegate = self
        
        let tap = UITapGestureRecognizer(target: self, action: Selector("chooseImg"))
        img.addGestureRecognizer(tap)
        
        let tap2 = UITapGestureRecognizer(target: self, action: "hide")
        view.addGestureRecognizer(tap2)
        ip.delegate = self
        // Do any additional setup after loading the view.
    }
    
    func hide()
    {
        txtfname.resignFirstResponder()
        txtemail.resignFirstResponder()
        txtpwd.resignFirstResponder()
    }
    
    
    func chooseImg()
    {
        ip.allowsEditing = false
        ip.sourceType = .PhotoLibrary
        
        presentViewController(ip, animated: true, completion: nil)
        
    
    
    }
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            img.contentMode = .ScaleAspectFit
            img.image = pickedImage
            let imgdata = UIImageJPEGRepresentation(pickedImage,0.8)
            userDef.setValue(imgdata, forKey: "Image")
            
        }
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        if txtfname.editing == true
        {
            txtfname.returnKeyType = .Next
        }
    }
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        if textField == txtfname
        {
            txtemail.becomeFirstResponder()
        
        }
        return true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
