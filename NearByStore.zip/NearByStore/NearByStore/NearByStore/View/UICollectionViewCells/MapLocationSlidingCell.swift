//
//  MapLocationSlidingCell.swift
//  NearByStore
//
//  Created by Ashish on 13/05/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import UIKit

class MapLocationSlidingCell: UICollectionViewCell {
    
    //Outlet
    @IBOutlet weak var vwContainer: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDistance: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblOpeningStatus: UILabel!
    @IBOutlet weak var btnViewStore: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        Utilities.decorateView(vwContainer.layer, cornerRadius: 5, borderWidth: 0, borderColor: UIColor.clear)
    }
}
