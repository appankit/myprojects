//
//  MapLocationListCell.swift
//  NearByStore
//
//  Created by Ashish on 13/05/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import UIKit

class MapLocationListCell: UITableViewCell{
    
    //Outlet
    @IBOutlet weak var vwContainer: UIView!
    @IBOutlet weak var lblLocationTitle: UILabel!
    @IBOutlet weak var imgLocation: UIImageView!
    @IBOutlet weak var lblDistance: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblOpeningStatus: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        Utilities.decorateView(vwContainer.layer, cornerRadius: 5, borderWidth: 0, borderColor: UIColor.clear)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}
