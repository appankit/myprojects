//
//  DeviceConstant.swift
//  NearByStore
//
//  Created by Ashish on 13/05/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import Foundation

class AppConstant: NSObject {
    static let deviceType = "Iphone"
    static let appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
    
    //MARK: API constants
    struct serverAPI {
        struct URL {
            static let kBaseURL                  = "https://dev.api.unoapp.io/locations/api/app/location/"
            static let kGetLocation              = kBaseURL + "search?radius=100000&withhours=1&unit=K&business_id=34&nofilter=0&longitude=%f&latitude=%f&map_lat=%f&map_long=%f"
        }
        
        struct errorMessages {
            static let kNoInternetConnectionMessage     = "Please check your internet connection."
            static let kCommanErrorMessage              = "Something went wrong please try again later."
        }
    }
}
