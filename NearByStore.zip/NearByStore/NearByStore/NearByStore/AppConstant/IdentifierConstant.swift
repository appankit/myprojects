//
//  IdentifierConstant.swift
//  NearByStore
//
//  Created by Ashish on 13/05/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import Foundation

//StoryBoard Identifiers
struct StoryBoardIdentifier {
    static let MainStoryBoard = "Main"
}

//View Controller Identifiers
struct ViewControllerIdentifier{
    static let DashBoardContainerVC = "DashBoardContainerVC"
    static let MapVC = "MapVC"
    static let MapLocationListVC = "MapLocationListVC"
 }

//Table view cell identifier
struct TableViewCellIdentifier {
    static let MapLocationListCell = "MapLocationListCell"
}

//Collection view cell identifier
struct CollectionViewCellIdentifier {
    static let MapLocationSlidingCell = "MapLocationSlidingCell"
}
