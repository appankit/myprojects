//
//  ColorConstant.swift
//  NearByStore
//
//  Created by Ashish on 13/05/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import Foundation

extension UIColor {
    //Custom color list used in app
    struct CustomColor {
        static let btnGreenBackgroundColor = UIColor(hex: "01D284")
    }
}
