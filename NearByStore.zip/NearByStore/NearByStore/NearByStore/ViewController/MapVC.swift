//
//  MapVC.swift
//  NearByStore
//
//  Created by Ashish on 13/05/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import UIKit

class MapVC: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    //MARk: IBOutlet
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var cvMapLocation: UICollectionView!
    
    //MARK: Variable
    var locationManager = CLLocationManager()
    var currentLocation: CLLocation?
    private var mapChangedFromUserInteraction = false
    
    //passed objects
    var objDashBoardContainerVC: DashBoardContainerVC?
    var arrPayload = [Payload]()
    
    //MARK: View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        
        // For use when the app is open & in the background
        //locationManager.requestAlwaysAuthorization()
        
        // For use when the app is open
        locationManager.requestWhenInUseAuthorization()
        
        // If location services is enabled get the users location
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest // You can change the locaiton accuary here.
            locationManager.startUpdatingLocation()
        }
        // Do any additional setup after loading the view.
    }
    
    // MARK: - MapView Delegate
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        //Defer Statement will execute when fucntion leave it's scope of execution
        defer {
            currentLocation = locations.last
            //self.getLocationData()
        }
        
        if currentLocation == nil {
            // Zoom to user location
            if let userLocation = locations.last {
                let viewRegion = MKCoordinateRegion(center: userLocation.coordinate, latitudinalMeters: 2000, longitudinalMeters: 2000)
                mapView.setRegion(viewRegion, animated: false)
            }
        }
    }
    
    // If we have been deined access give the user the option to change it
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if(status == CLAuthorizationStatus.authorizedWhenInUse) {
            currentLocation = locationManager.location
            //Call API to get data based on user location
            self.objDashBoardContainerVC?.getLocationData(userCoordinate: currentLocation?.coordinate, mapCenterCoordinate: nil)
        }
    }

    //MapView annotation view
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        //Identify user location
        if annotation is MKUserLocation
        {
            return nil
        }
        var annotationView = self.mapView.dequeueReusableAnnotationView(withIdentifier: "Pin")
        if annotationView == nil{
            annotationView = AnnotationView(annotation: annotation, reuseIdentifier: "Pin")
            annotationView?.canShowCallout = false
        }else{
            annotationView?.annotation = annotation
        }
        //Set custom annotation image
        annotationView?.image = UIImage(named: "MapPin")
        return annotationView
    }
    
    //Mapview Region change methods
    func mapView(_ mapView: MKMapView, regionWillChangeAnimated animated: Bool) {
        mapChangedFromUserInteraction = mapViewRegionDidChangeFromUserInteraction()
        if (mapChangedFromUserInteraction) {
            // user changed map region
            print("user will changee map region")
        }
    }
    
    func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
        if (mapChangedFromUserInteraction) {
            // user changed map region
            print("user did completed changing map region")
            self.objDashBoardContainerVC?.getLocationData(userCoordinate: currentLocation?.coordinate, mapCenterCoordinate: mapView.centerCoordinate)
        }
    }
    
    //MARK: UICollectionview Methods
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrPayload.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: ScreenSize.SCREEN_WIDTH * 0.9, height: cvMapLocation.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CollectionViewCellIdentifier.MapLocationSlidingCell, for: indexPath as IndexPath) as! MapLocationSlidingCell
        
        //TODO: IMPROOVE THIS CODE IN CELL
        let objPayload = arrPayload[indexPath.item]
        
        cell.lblTitle.text = objPayload.display_name
        cell.lblDistance.text = "\(objPayload.distance ?? 0) km"
        cell.lblAddress.text = objPayload.address_line_1

        let objLocationHours = objPayload.location_hours?.first(where: { $0.day == Date().dayNumberOfWeek() })
        
        //Date formatter to conver start time and end time
        let dateFormatter = DateFormatter.dateformatter(withformat: .HHmmss)
        let date = dateFormatter.date(from: (objLocationHours?.open_time ?? ""))
        let dateFormatter1 = DateFormatter.dateformatter(withformat: .hmma)
        let startTime = dateFormatter1.string(from: date ?? Date())
        
        let date1 = dateFormatter.date(from: (objLocationHours?.close_time ?? ""))
        let closeTime = dateFormatter1.string(from: date1 ?? Date())
        
        //Mutable string to set opening and closing status
        var mutableString = NSMutableAttributedString()
        if objLocationHours?.status == 1{
            mutableString = NSMutableAttributedString(string: "Open now", attributes: [NSAttributedString.Key.foregroundColor: UIColor.green])
        }else{
            mutableString = NSMutableAttributedString(string: "Closed now", attributes: [NSAttributedString.Key.foregroundColor: UIColor.red])
        }
        mutableString.append(NSAttributedString(string: " \u{2022} \(startTime) - \(closeTime)"))
        cell.lblOpeningStatus.attributedText = mutableString

        //Set View store appearance
        cell.btnViewStore.isEnabled = objLocationHours?.status == 1
        cell.btnViewStore.alpha = objLocationHours?.status == 1 ? 1:0.5
        cell.btnViewStore.backgroundColor = objLocationHours?.status == 1 ? UIColor.CustomColor.btnGreenBackgroundColor:UIColor.gray
        return cell
    }
    
    //MARK: Private Methods
    func setMapPayloadAndReload(arrPayload: [Payload]){
        self.arrPayload =  arrPayload
        self.cvMapLocation.reloadData()
        
        //Add annotation pins
        self.addPinOnNearByLocation()
    }
    
//    func addPin() {
//        let allAnnotations = self.mapView.annotations
//        self.mapView.removeAnnotations(allAnnotations)
//
//        let annotation = MKPointAnnotation()
//        let centerCoordinate = CLLocationCoordinate2D(latitude: self.currentLocation?.coordinate.latitude ?? 0, longitude: self.currentLocation?.coordinate.longitude ?? 0)
//        annotation.coordinate = centerCoordinate
//        annotation.title = ""
//        mapView.addAnnotation(annotation)
//
//        self.addPinOnNearByLocation()
//    }
    
    //Add annotation pin to location
    func addPinOnNearByLocation(){
        //remove old annotations before adding new annotations
        let allAnnotations = self.mapView.annotations
        self.mapView.removeAnnotations(allAnnotations)
        
        for objPayload in arrPayload{
            let objMapPin = MapPin(coordinate: CLLocationCoordinate2D(latitude: Double(objPayload.latitude ?? "") ?? 0, longitude: Double(objPayload.longitude ?? "") ?? 0), title: objPayload.display_name ?? "", subtitle: "")
            mapView.addAnnotation(objMapPin)
        }
    }
    
    //This Method used to identify user interaction ends
    private func mapViewRegionDidChangeFromUserInteraction() -> Bool {
        let view = self.mapView.subviews[0]
        //  Look through gesture recognizers to determine whether this region change is from user interaction
        if let gestureRecognizers = view.gestureRecognizers {
            for recognizer in gestureRecognizers {
                if( recognizer.state == UIGestureRecognizer.State.began || recognizer.state == UIGestureRecognizer.State.ended ) {
                    return true
                }
            }
        }
        return false
    }
}
