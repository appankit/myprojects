//
//  MapLocationListVC.swift
//  NearByStore
//
//  Created by Ashish on 13/05/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import UIKit

class MapLocationListVC: UIViewController, UITableViewDelegate, UITableViewDataSource {

    //MARK: IBOutlet
    @IBOutlet weak var tblMapLocationList: UITableView!
    
    //MARK: Variable
    var objDashBoardContainerVC: DashBoardContainerVC?
    var arrPayload = [Payload]()
    
    //MARK: View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tblMapLocationList.tableFooterView = UIView()
        // Do any additional setup after loading the view.
    }
    
    //MARK: UITableView Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrPayload.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 88
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: TableViewCellIdentifier.MapLocationListCell, for: indexPath) as! MapLocationListCell
        
        //TODO: IMPROOVE THIS CODE IN CELL
        let objPayload = arrPayload[indexPath.item]
        
        cell.imgLocation.sd_setImage(with: URL(string: objPayload.image_url ?? ""), placeholderImage: UIImage(named: "PlaceHolder"), options: SDWebImageOptions(rawValue: 0))
        
        cell.lblLocationTitle.text = objPayload.display_name
        cell.lblDistance.text = "\(objPayload.distance ?? 0) km"
        cell.lblAddress.text = objPayload.address_line_1
        
        let objLocationHours = objPayload.location_hours?.first(where: { $0.day == Date().dayNumberOfWeek() })
        
        //Date formatter to conver start time and end time
        let dateFormatter = DateFormatter.dateformatter(withformat: .HHmmss)
        let date = dateFormatter.date(from: (objLocationHours?.open_time ?? ""))
        let dateFormatter1 = DateFormatter.dateformatter(withformat: .hmma)
        let startTime = dateFormatter1.string(from: date ?? Date())
        
        let date1 = dateFormatter.date(from: (objLocationHours?.close_time ?? ""))
        let closeTime = dateFormatter1.string(from: date1 ?? Date())
        
        //Mutable string to set opening and closing status
        var mutableString = NSMutableAttributedString()
        if objLocationHours?.status == 1{
            mutableString = NSMutableAttributedString(string: "Open now", attributes: [NSAttributedString.Key.foregroundColor: UIColor.green])
        }else{
            mutableString = NSMutableAttributedString(string: "Closed now", attributes: [NSAttributedString.Key.foregroundColor: UIColor.red])
        }
        mutableString.append(NSAttributedString(string: " \u{2022} \(startTime) - \(closeTime)"))
        
        cell.lblOpeningStatus.attributedText = mutableString
        
        return cell
    }
    
    //MARK: Private Methods
    func setMapPayloadAndReload(arrPayload: [Payload]){
        //Reload data
        self.arrPayload =  arrPayload
        self.tblMapLocationList.reloadData()
    }
}
