//
//  DateFormatter+Addition.swift
//  NearByStore
//
//  Created by Ashish on 13/05/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import Foundation

enum DateFormatterList : String {
    case HHmmss = "HH:mm:ss",
    hmma = "h:mm a"
}

extension DateFormatter {
    class func dateformatter(withformat: DateFormatterList) -> DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = withformat.rawValue
        formatter.timeZone = TimeZone.current
        formatter.locale = Locale(identifier: "en_US_POSIX")
        return formatter
    }
}
