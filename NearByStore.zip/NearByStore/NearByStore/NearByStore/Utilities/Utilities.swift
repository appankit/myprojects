//
//  Utilities.swift
//  NearByStore
//
//  Created by Ashish on 13/05/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import UIKit

class Utilities: NSObject {
    //MARK: Decorate view with border and corner radius
    class func decorateView(_ layer: CALayer, cornerRadius: CGFloat, borderWidth: CGFloat, borderColor: UIColor?){
        layer.cornerRadius = cornerRadius
        layer.borderWidth = borderWidth
        layer.borderColor = borderColor?.cgColor
        layer.masksToBounds = true
    }
    
    //MARK: Decorate view with corner radius and background color
    class func giveCornerRadiusAndBGColor(_ layer: CALayer, bgColor: UIColor) {
        layer.cornerRadius = layer.frame.width / 2
        layer.backgroundColor = bgColor.cgColor
    }
    
    //MARK: Decorate view with rounded corner radius
    class func setRoundedCornerRadius(_ layer: CALayer, borderColor: UIColor, borderWidth: CGFloat)
    {
        layer.cornerRadius = layer.frame.width / 2
        layer.borderColor = borderColor.cgColor
        layer.borderWidth = borderWidth
        layer.masksToBounds = true
    }
    
    //MARK: Check internet connection
    static func checkInternetConnection() -> Bool
    {
        if(APIManager.sharedInstance.isConnectedToNetwork())
        {
            return true
        }else{
            return false
        }
    }
    
    //Show toast
    class func showCustomToast(message: String?) {
        if let msg = message, msg.count > 0
        {
            DispatchQueue.main.async {
                let topView = UIApplication.topViewController()
                topView?.view.hideAllToasts()
                topView?.view.makeToast(msg, duration: 3.0, point: CGPoint(x: (topView?.view.center.x) ?? 0, y: (topView?.view.center.y) ?? 0), title: nil, image: nil, style: ToastStyle.init(), completion: nil)
            }
        }
    }
}

