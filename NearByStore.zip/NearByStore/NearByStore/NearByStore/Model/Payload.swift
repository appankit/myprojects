/* 
Copyright (c) 2019 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

import Foundation
 
/* For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar */

public class Payload {
	public var id : Int?
	public var region_id : Int?
	public var business_id : Int?
	public var internal_id : String?
	public var slug : String?
	public var api_key : String?
	public var name : String?
	public var display_name : String?
	public var address_line_1 : String?
	public var address_line_2 : String?
	public var city : String?
	public var province : String?
	public var postal_code : String?
	public var country_code : String?
	public var country : String?
	public var latitude : String?
	public var longitude : String?
	public var email : String?
	public var phone : String?
	public var fax : String?
	public var timezone : String?
	public var currency : String?
	public var status : Int?
	public var is_corporate : Int?
	public var approved_domains : String?
	public var created_by : Int?
	public var updated_by : Int?
	public var created_at : String?
	public var updated_at : String?
	public var deleted_at : String?
	public var distance : Double?
	public var is_emergency_closed : Int?
	public var region_name : String?
	public var is_open : Int?
	public var image_url : String?
	public var location_hours : [Location_hours]?
	public var location_holiday_hours : [String]?
	public var location_profile : Location_profile?
	public var region : Region?

    public class func modelsFromDictionaryArray(array: [[String: Any]]) -> [Payload]
    {
        var models:[Payload] = []
        for item in array
        {
            models.append(Payload(dictionary: item)!)
        }
        return models
    }

    required public init?(dictionary: [String: Any]) {

		id = dictionary["id"] as? Int
		region_id = dictionary["region_id"] as? Int
		business_id = dictionary["business_id"] as? Int
		internal_id = dictionary["internal_id"] as? String
		slug = dictionary["slug"] as? String
		api_key = dictionary["api_key"] as? String
		name = dictionary["name"] as? String
		display_name = dictionary["display_name"] as? String
		address_line_1 = dictionary["address_line_1"] as? String
		address_line_2 = dictionary["address_line_2"] as? String
		city = dictionary["city"] as? String
		province = dictionary["province"] as? String
		postal_code = dictionary["postal_code"] as? String
		country_code = dictionary["country_code"] as? String
		country = dictionary["country"] as? String
		latitude = dictionary["latitude"] as? String
		longitude = dictionary["longitude"] as? String
		email = dictionary["email"] as? String
		phone = dictionary["phone"] as? String
		fax = dictionary["fax"] as? String
		timezone = dictionary["timezone"] as? String
		currency = dictionary["currency"] as? String
		status = dictionary["status"] as? Int
		is_corporate = dictionary["is_corporate"] as? Int
		approved_domains = dictionary["approved_domains"] as? String
		created_by = dictionary["created_by"] as? Int
		updated_by = dictionary["updated_by"] as? Int
		created_at = dictionary["created_at"] as? String
		updated_at = dictionary["updated_at"] as? String
		deleted_at = dictionary["deleted_at"] as? String
		distance = dictionary["distance"] as? Double
		is_emergency_closed = dictionary["is_emergency_closed"] as? Int
		region_name = dictionary["region_name"] as? String
		is_open = dictionary["is_open"] as? Int
		image_url = dictionary["image_url"] as? String
		
        if let arrLocationHoursData = dictionary["location_hours"] as? [[String: Any]]{
           location_hours = Location_hours.modelsFromDictionaryArray(array: arrLocationHoursData)
        }
        
        if let arrLocationHolidayHoursData = dictionary["location_holiday_hours"] as? [String]{
            location_holiday_hours = arrLocationHolidayHoursData
        }
        
        if let objLocationProfileData = dictionary["location_profile"] as? [String: Any]{
            location_profile = Location_profile(dictionary: objLocationProfileData)
        }
        
        if let objRegionData = dictionary["region"] as? [String: Any]{
            region = Region(dictionary: objRegionData)
        }
        
        //if (dictionary["location_hours"] != nil) { location_hours = Location_hours.modelsFromDictionaryArray(dictionary["location_hours"] as! NSArray) }
		//if (dictionary["location_holiday_hours"] != nil) { location_holiday_hours = Location_holiday_hours.modelsFromDictionaryArray(dictionary["location_holiday_hours"] as! NSArray) }
		//if (dictionary["location_profile"] != nil) { location_profile = Location_profile(dictionary: dictionary["location_profile"] as! NSDictionary) }
		//if (dictionary["region"] != nil) { region = Region(dictionary: dictionary["region"] as! NSDictionary) }
	}
    
    //MARK: API Call
    class func fetchLocationData(lat: Double, long: Double, mapLat: Double, mapLong: Double, success withResponse: @escaping (_ arrPayload: [Payload]?) -> (), failure: @escaping (_ error: String) -> Void, connectionFail: @escaping (_ error: String) -> Void){
        SVProgressHUD.show()
        
        let requestURL = String(format: AppConstant.serverAPI.URL.kGetLocation, long, lat, mapLat, mapLong)
        
        APIManager.sharedInstance.callURLStringJson(requestURL, httpMethod: .get, withRequest: nil, withSuccess: { (response) in
            if let res = response as? [String:Any] {
                if res["code"] as? Int == 200 {
                    if let arrPayloadData = res["payload"] as? [[String:Any]], arrPayloadData.count > 0 {
                        let arrPayload = Payload.modelsFromDictionaryArray(array: arrPayloadData)
                        withResponse(arrPayload)
                    }else{
                        withResponse(nil)
                    }
                } else {
                    let msg = res["message"] as? String
                    Utilities.showCustomToast(message: msg ?? "")
                    failure(msg ?? "")
                }
            }
            SVProgressHUD.dismiss()
        }, failure: { (error) in
            SVProgressHUD.dismiss()
            Utilities.showCustomToast(message: error)
            failure(error)
        }, connectionFailed: { (connectionFailed) in
            SVProgressHUD.dismiss()
            Utilities.showCustomToast(message: connectionFailed)
            connectionFail(connectionFailed)
        })
    }
}
