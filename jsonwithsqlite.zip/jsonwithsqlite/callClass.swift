//
//  callClass.swift
//  jsonwithsqlite
//
//  Created by Harry on 2/11/16.
//  Copyright © 2016 Harry. All rights reserved.
//

import Foundation
import UIKit
var dataFromJson = NSMutableArray()
var index:Int = Int()
var jsonResult = NSDictionary()
var result = NSMutableDictionary()
var city1 = ""
var lon = ""
var lati = ""
var mv = ""
var img = ""
var actor = ""
var director = ""
var language = ""
var genre = ""
var dateshow = ""
var video = ""
var dataFromDb = NSMutableArray()
var handler:COpaquePointer = COpaquePointer()
var stmt = COpaquePointer()
func dbPathFetch()-> String
{
    
    
    let path=(NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory,NSSearchPathDomainMask.UserDomainMask, true)[0]) as String
    let dbpath = (path as NSString).stringByAppendingPathComponent("mydb_json")
    print(dbpath)
    return dbpath
}

class BookMyShow
{

    
    init()
    {
        
        let str = NSString(format:  "http://data.in.bookmyshow.com/getData.aspx?cc=&cmd=GETEVENTLIST&dt=&et=MT&f=json&lg=%@&lt=%@&rc=%@&sr=&t=a54a7b3aba576256614a", lon,lati,city1)
        
        let dataFromUrl = NSURL(string: str as String)
        let data = NSData(contentsOfURL: dataFromUrl!)
        
       if NSFileManager.defaultManager().fileExistsAtPath(dbPathFetch()) == false
        {
            if (sqlite3_open(dbPathFetch(),&handler) == SQLITE_OK)
            {
            let tbl = "create table jsonData(id integer primary key,movie text,imgurl text,actor text,director text,language text,genre text,showdate text,video text)"
            var errMsg:UnsafeMutablePointer<Int8> = nil
            if sqlite3_exec(handler,tbl,nil,nil,&errMsg) == SQLITE_OK
            {
                
                print("table created")
                
                
                
                
            }
            else
            {
                
                print("table not created")
                
            }
            }
            
            
        }
        

        
        
        
      /* if (sqlite3_open(dbPathFetch(),&handler) == SQLITE_OK)
        {
            // NSData *imageData = UIImagePNGRepresentation(theImage);
            
            //sqlite3_bind_blob(statement, 1, [imageData bytes], [imageData length], SQLITE_TRANSIENT);
            //var data = UIImagePNGRepresentation(img)
            
            var insert = "insert into demo2(name,contact,image) values('"+name.text!+"','"+contact.text!+"','\(imgdata)')"
            //print(insert)
            
            
            
            var errMsg:UnsafeMutablePointer<Int8> = nil
            if sqlite3_exec(handler,insert,nil,nil,&errMsg) == SQLITE_OK
            {
                //sqlite3_bind_blob(handler, 3, imgdata.bytes, Int32(imgdata.length) , nil)
                print("data inserted")
                var sec:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                var sec2 = sec.instantiateViewControllerWithIdentifier("display")
              //  navigationController?.pushViewController(sec2, animated: true)
                
            }
            else
            {
                
                print("data not inserted")
                
            }
            
        }*/

        
        
        
        

        
        
        
        
        
        
        
        do
        {
            dataFromJson.removeAllObjects()
            jsonResult = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions()) as! NSDictionary
            let keyForBM = jsonResult.objectForKey("BookMyShow")
            let keys = keyForBM?.objectForKey("arrEvent") as! NSArray
            
            
            if (sqlite3_open(dbPathFetch(),&handler) == SQLITE_OK)
            {
                
                let delete = "delete from jsonData"
                //print(insert)
                var errMsg:UnsafeMutablePointer<Int8> = nil
                if sqlite3_exec(handler,delete,nil,nil,&errMsg) == SQLITE_OK
                {
                    
                  //  print("data deleted")
                    
                    
                }
                else
                {
                    
                  //  print("data not deleted")
                    
                }

            }
            
            
            
            
            
            for key1  in keys
            {
                
                
                
                if (sqlite3_open(dbPathFetch(),&handler) == SQLITE_OK)
                {
                    
                    var mv = key1["EventTitle"] as! String
                     var imgurl = key1["BannerURL"] as! String
                    var actor = key1["Actors"] as! String
                   
                    var director = key1["Director"] as! String
                    var lang = key1["Language"] as! String
                    var genre = key1["Genre"] as! String
                    var showDate = key1["arrDates"]!![0]["ShowDateDisplay"] as! String
                    var v = key1["TrailerURL"] as! String
                    var insert = "insert into jsonData(movie,imgurl,actor,director,language,genre,showdate,video)values('\(mv)','\(imgurl)','\(actor)','\(director)','\(lang)','\(genre)','\(showDate)','\(v)')"
                    print(insert)
                
                    
                    
                    var errMsg:UnsafeMutablePointer<Int8> = nil
                    if sqlite3_exec(handler,insert,nil,nil,&errMsg) == SQLITE_OK
                    {
                                                print("data inserted")
                      
                        
                    }
                    else
                    {
                        
                        print("data not inserted")
                        
                    }
                    
                }

                
                
                
                
                
                
                
                
                
                
                //print(key1["arrDates"]!![0]["ShowDateDisplay"])
                
            }
            
            // print(actor[0]["Actors"])
            
           // print(dataFromJson[0]["Actors"])
            
            // print(keyForBM!["arrEvent"]!![0]["EventTitle"]!)
            
            
            
            if (sqlite3_open(dbPathFetch(),&handler) == SQLITE_OK)
            {
              // var data = "select * from "
                
                let querySQL = "SELECT * FROM jsonData"
                //let query_stmt = querySQL.UTF8String as COpaquePointer
                //print(query_stmt)
                var errMsg:UnsafeMutablePointer<Int8> = nil
                
                
                if(sqlite3_prepare_v2(handler, querySQL, -1, &stmt, nil) == SQLITE_OK)
                {
                        var i = 0
                    while (sqlite3_step(stmt)==SQLITE_ROW)
                    {
                        
                        
                        
                         mv = String.fromCString(UnsafePointer<Int8>(sqlite3_column_text(stmt, 1)))!
                        img = String.fromCString(UnsafePointer<Int8>(sqlite3_column_text(stmt, 2)))!
                        actor = String.fromCString(UnsafePointer<Int8>(sqlite3_column_text(stmt, 3)))!
                        director = String.fromCString(UnsafePointer<Int8>(sqlite3_column_text(stmt, 4)))!
                        language = String.fromCString(UnsafePointer<Int8>(sqlite3_column_text(stmt, 5)))!
                        genre = String.fromCString(UnsafePointer<Int8>(sqlite3_column_text(stmt, 6)))!
                        dateshow = String.fromCString(UnsafePointer<Int8>(sqlite3_column_text(stmt, 7)))!
                        video = String.fromCString(UnsafePointer<Int8>(sqlite3_column_text(stmt, 8)))!
                        
                        
                        
                        dataFromDb.addObject([mv,img,actor,director,language,genre,dateshow,video])
                        
                        
                        //use.addObject(String.fromCString(UnsafePointer<Int8>(sqlite3_column_text(stmt, 1)))!)
                       // id.addObject(String.fromCString(UnsafePointer<Int8>(sqlite3_column_text(stmt, 0)))!)
                       // num.addObject(String.fromCString(UnsafePointer<Int8>(sqlite3_column_text(stmt, 2)))!)
                       // var ss: NSString = NSString(UTF8String:UnsafePointer<Int8>(sqlite3_column_text(stmt, 3)))!
                       // print(ss)
                        //imgdis.image = UIImage(named: <#T##String#>)                     //ss = (ss.stringWithUTF8String(Character(sqlite3_column_text(stmt, 3))))as NSString
                        
                        
                    }
                }
            }

            
            
            
            
            
            
            
            
            
        }
        catch
        {
            
            
            
        }
        
    }






}