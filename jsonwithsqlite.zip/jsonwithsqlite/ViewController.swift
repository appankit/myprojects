//
//  ViewController.swift
//  jsonwithsqlite
//
//  Created by Harry on 2/11/16.
//  Copyright © 2016 Harry. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    var handler:COpaquePointer = COpaquePointer()
    var stmt = COpaquePointer()
    override func viewDidLoad() {
        super.viewDidLoad()
      /*  if NSFileManager.defaultManager().fileExistsAtPath(dbPathFetch()) == false
        {
        
            var tbl = "create table jsonData(id integer primary key,imgurl text,actor text,director text,language text,genre text,showdate text)"
            var errMsg:UnsafeMutablePointer<Int8> = nil
            if sqlite3_exec(handler,tbl,nil,nil,&errMsg) == SQLITE_OK
            {
                
                print("table created")
                
                
                
                
            }
            else
            {
                
                print("table not created")
                
            }

        
        
        }*/
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func dbPathFetch()-> String
    {
        
        
        let path=(NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory,NSSearchPathDomainMask.UserDomainMask, true)[0]) as String
        let dbpath = (path as NSString).stringByAppendingPathComponent("mydb4")
        print(dbpath)
        return dbpath
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     //   print(dataFromDb[1][0])
        return dataFromDb.count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
        cell.textLabel?.text = dataFromDb[indexPath.row][0] as! String
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let sec:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let sec2 = sec.instantiateViewControllerWithIdentifier("display") //as! display
        index = indexPath.row
        
        
        self.presentViewController(sec2, animated: true, completion: nil)
        
        
        
    }

}

